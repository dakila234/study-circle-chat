package studycircle;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Server-side state of the shared Question Queue (Study Circle feature #1).
 * Every method is synchronized because many ClientHandler threads write to it.
 * Methods return the protocol line to broadcast, or null with an error in lastError-style
 * Result objects.
 */
class QuestionBoard {

    /** Result of an operation: either a line to broadcast or an error message. */
    static final class Result {
        final String line;
        final String error;
        final String info;

        private Result(String line, String info, String error) {
            this.line = line;
            this.info = info;
            this.error = error;
        }

        static Result ok(String line, String info) { return new Result(line, info, null); }
        static Result fail(String error) { return new Result(null, null, error); }
        boolean isOk() { return error == null; }
    }

    private static final int MAX_QUESTIONS = 200;

    private final List<Question> questions = new ArrayList<>();
    private int nextId = 1;

    synchronized void reset() {
        questions.clear();
        nextId = 1;
    }

    synchronized Result add(String author, String text) {
        text = text == null ? "" : text.trim();
        if (text.isEmpty()) {
            return Result.fail("Question cannot be empty.");
        }
        if (text.length() > Protocol.MAX_QUESTION) {
            text = text.substring(0, Protocol.MAX_QUESTION);
        }
        if (questions.size() >= MAX_QUESTIONS) {
            return Result.fail("The question queue is full.");
        }
        Question q = new Question(nextId++, author, text);
        questions.add(q);
        return Result.ok(q.toLine(), author + " asked question #" + q.id + ": " + text);
    }

    synchronized Result upvote(int id, String user) {
        Question q = find(id);
        if (q == null) {
            return Result.fail("No question with number " + id + ".");
        }
        if (q.answered) {
            return Result.fail("Question #" + id + " is already answered.");
        }
        if (q.author.equalsIgnoreCase(user)) {
            return Result.fail("You cannot +1 your own question.");
        }
        if (!q.upvoters.add(user.toLowerCase(Locale.ROOT))) {
            return Result.fail("You already +1'd question #" + id + ".");
        }
        return Result.ok(q.toLine(), null);
    }

    synchronized Result markAnswered(int id, String user) {
        Question q = find(id);
        if (q == null) {
            return Result.fail("No question with number " + id + ".");
        }
        if (q.answered) {
            return Result.fail("Question #" + id + " is already answered.");
        }
        q.answered = true;
        q.answeredBy = user;
        return Result.ok(q.toLine(), user + " marked question #" + id + " as answered.");
    }

    /** All current questions as protocol lines (used when a new client joins). */
    synchronized List<String> snapshotLines() {
        List<String> lines = new ArrayList<>();
        for (Question q : questions) {
            lines.add(q.toLine());
        }
        return lines;
    }

    private Question find(int id) {
        for (Question q : questions) {
            if (q.id == id) {
                return q;
            }
        }
        return null;
    }
}
