package studycircle;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.UIManager;

/** Colours, fonts and small styling helpers so every window looks like the same app. */
final class Theme {

    static final Color NAVY = new Color(0x1F3A5F);
    static final Color AMBER = new Color(0xF2A541);
    static final Color PAPER = new Color(0xFAF7F0);
    static final Color INK = new Color(0x22303F);
    static final Color MUTED = new Color(0x6B7785);
    static final Color GREEN = new Color(0x2E7D5B);
    static final Color PURPLE = new Color(0x7B4FA3);
    static final Color RED = new Color(0xB3382C);
    static final Color DONE_ROW = new Color(0xE3F1EA);

    static final Font BASE = new Font("SansSerif", Font.PLAIN, 14);
    static final Font BOLD = new Font("SansSerif", Font.BOLD, 14);
    static final Font TITLE = new Font("SansSerif", Font.BOLD, 22);

    private Theme() { }

    static void apply() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // fall back to the default look and feel
        }
        UIManager.put("defaultFont", BASE);
    }

    static JButton primaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(AMBER);
        b.setForeground(INK);
        b.setFont(BOLD);
        return b;
    }

    static JLabel titleLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(TITLE);
        l.setForeground(Color.WHITE);
        return l;
    }

    static JLabel mutedLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(MUTED);
        return l;
    }

    static javax.swing.border.Border padding(int px) {
        return BorderFactory.createEmptyBorder(px, px, px, px);
    }
}
