package studycircle;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/**
 * Main Study Circle window: group chat on the left; online list, question queue
 * and poll on the right. All messages from the server arrive on the reader thread
 * and are moved to the Swing thread with SwingUtilities.invokeLater before touching the GUI.
 */
public class MainFrame extends JFrame implements ClientConnection.Listener {

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    private final ClientConnection connection;
    private final String nick;
    private final String host;
    private final int port;

    private final JTextPane chatPane = new JTextPane();
    private final JTextField inputField = new JTextField();
    private final JButton sendButton = Theme.primaryButton("Send");
    private final JLabel statusLabel = new JLabel();
    private final DefaultListModel<String> usersModel = new DefaultListModel<>();
    private final JList<String> usersList = new JList<>(usersModel);
    private final QuestionPanel questionPanel;
    private final PollPanel pollPanel;
    private final JTabbedPane tabs = new JTabbedPane();

    private boolean connected = true;

    public MainFrame(ClientConnection connection, String nick, String host, int port) {
        super("Study Circle - " + nick);
        this.connection = connection;
        this.nick = nick;
        this.host = host;
        this.port = port;
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        questionPanel = new QuestionPanel(connection::send);
        pollPanel = new PollPanel(connection::send, nick);

        buildLayout();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                leave();
            }
        });

        appendSystem(now(), "Welcome to the circle, " + nick + ". Type /help to see commands.");
        connection.startReading(this);   // start only after the GUI exists
    }

    private void buildLayout() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.NAVY);
        header.setBorder(Theme.padding(10));
        header.add(Theme.titleLabel("Study Circle"), BorderLayout.WEST);
        statusLabel.setForeground(Theme.AMBER);
        statusLabel.setFont(Theme.BOLD);
        statusLabel.setText(nick + "  @  " + host + ":" + port + "  |  online");
        header.add(statusLabel, BorderLayout.EAST);

        // left: chat
        chatPane.setEditable(false);
        chatPane.setBackground(Theme.PAPER);
        chatPane.setBorder(Theme.padding(6));
        JScrollPane chatScroll = new JScrollPane(chatPane);

        JPanel inputRow = new JPanel(new BorderLayout(6, 0));
        inputRow.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 0, 0, 0));
        inputRow.add(inputField, BorderLayout.CENTER);
        inputRow.add(sendButton, BorderLayout.EAST);
        sendButton.addActionListener(e -> submitInput());
        inputField.addActionListener(e -> submitInput());

        JPanel chatPanel = new JPanel(new BorderLayout());
        chatPanel.setBorder(Theme.padding(8));
        chatPanel.add(chatScroll, BorderLayout.CENTER);
        chatPanel.add(inputRow, BorderLayout.SOUTH);

        // right: tabs
        JPanel usersPanel = new JPanel(new BorderLayout());
        usersPanel.setBorder(Theme.padding(8));
        usersPanel.add(Theme.mutedLabel("Who is studying right now (double-click to /msg)"), BorderLayout.NORTH);
        usersPanel.add(new JScrollPane(usersList), BorderLayout.CENTER);
        usersList.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2 && usersList.getSelectedValue() != null) {
                    inputField.setText("/msg " + usersList.getSelectedValue() + " ");
                    inputField.requestFocusInWindow();
                }
            }
        });

        tabs.addTab("Online", usersPanel);
        tabs.addTab("Questions", questionPanel);
        tabs.addTab("Poll", pollPanel);
        tabs.setPreferredSize(new Dimension(380, 400));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, chatPanel, tabs);
        split.setResizeWeight(0.55);
        split.setBorder(null);

        add(header, BorderLayout.NORTH);
        add(split, BorderLayout.CENTER);

        setSize(980, 600);
        setMinimumSize(new Dimension(760, 460));
        setLocationRelativeTo(null);
    }

    // ---- sending -------------------------------------------------------------------------

    private void submitInput() {
        String text = inputField.getText().trim();
        if (text.isEmpty() || !connected) {
            return;
        }
        inputField.setText("");
        if (text.startsWith("/")) {
            runCommand(text);
        } else {
            connection.send(Protocol.build("MSG", text));
        }
    }

    /** Slash commands typed in the chat box. */
    private void runCommand(String text) {
        String[] parts = text.split("\\s+", 3);
        String cmd = parts[0].toLowerCase();
        switch (cmd) {
            case "/help":
                appendSystem(now(), "Commands: /list  /msg <nick> <text>  /quit  /ask <question>  "
                        + "/up <#>  /done <#>  /poll Question | option | option  /vote <option number>  /endpoll");
                break;
            case "/list":
                connection.send(Protocol.build("LIST"));
                break;
            case "/quit":
                leave();
                break;
            case "/msg":
                if (parts.length < 3) {
                    appendError("Usage: /msg <nickname> <text>");
                } else {
                    connection.send(Protocol.build("PM", parts[1], parts[2]));
                }
                break;
            case "/ask":
                connection.send(Protocol.build("Q_ADD", text.substring(4).trim()));
                break;
            case "/up":
                connection.send(Protocol.build("Q_UP", parts.length > 1 ? parts[1] : ""));
                break;
            case "/done":
                connection.send(Protocol.build("Q_DONE", parts.length > 1 ? parts[1] : ""));
                break;
            case "/poll": {
                String body = text.length() > 5 ? text.substring(5) : "";
                List<String> fields = new ArrayList<>();
                for (String f : body.split("\\|")) {
                    fields.add(f.trim());
                }
                connection.send(Protocol.build("POLL_START", fields.toArray(new String[0])));
                break;
            }
            case "/vote": {
                try {
                    int n = Integer.parseInt(parts.length > 1 ? parts[1] : "");
                    connection.send(Protocol.build("POLL_VOTE", String.valueOf(n - 1)));
                } catch (NumberFormatException e) {
                    appendError("Usage: /vote <option number>");
                }
                break;
            }
            case "/endpoll":
                connection.send(Protocol.build("POLL_END"));
                break;
            default:
                appendError("Unknown command. Type /help.");
        }
    }

    private void leave() {
        if (connected) {
            connected = false;
            connection.disconnect();
        }
        dispose();
        new ConnectFrame().setVisible(true);
    }

    // ---- receiving (ClientConnection.Listener) --------------------------------------------

    @Override
    public void onMessage(String[] p) {
        SwingUtilities.invokeLater(() -> handleMessage(p));
    }

    @Override
    public void onClosed() {
        SwingUtilities.invokeLater(() -> {
            if (!connected) {
                return;
            }
            connected = false;
            inputField.setEnabled(false);
            sendButton.setEnabled(false);
            statusLabel.setText(nick + "  |  DISCONNECTED");
            statusLabel.setForeground(Color.WHITE);
            appendError("Lost connection to the server.");
            JOptionPane.showMessageDialog(this, "The connection to the server was lost.\n"
                    + "You will be taken back to the join screen.",
                    "Disconnected", JOptionPane.WARNING_MESSAGE);
            dispose();
            new ConnectFrame().setVisible(true);
        });
    }

    private void handleMessage(String[] p) {
        switch (p[0]) {
            case "MSG":
                appendChat(Protocol.arg(p, 1), Protocol.arg(p, 2), Protocol.arg(p, 3));
                break;
            case "SYS":
                appendSystem(Protocol.arg(p, 1), Protocol.arg(p, 2));
                break;
            case "PM":
                appendPrivate(Protocol.arg(p, 1), Protocol.arg(p, 2), Protocol.arg(p, 3), Protocol.arg(p, 4));
                break;
            case "ERR":
                appendError(Protocol.arg(p, 1));
                break;
            case "USERS": {
                List<String> names = new ArrayList<>(Arrays.asList(p).subList(1, p.length));
                usersModel.clear();
                for (String n : names) {
                    usersModel.addElement(n);
                }
                tabs.setTitleAt(0, "Online (" + names.size() + ")");
                pollPanel.setOnlineUsers(names);
                break;
            }
            case "Q_RESET":
                questionPanel.reset();
                break;
            case "Q_SET":
                questionPanel.applyQuestion(p);
                break;
            case "POLL_STATE":
                pollPanel.applyState(p);
                break;
            default:
                break;
        }
    }

    // ---- chat rendering --------------------------------------------------------------------

    private void appendChat(String time, String sender, String text) {
        boolean mine = sender.equalsIgnoreCase(nick);
        append("[" + time + "] ", style(Theme.MUTED, false, false));
        append(sender + ": ", style(mine ? Theme.NAVY : Theme.GREEN, true, false));
        append(text + "\n", style(Theme.INK, false, false));
    }

    private void appendPrivate(String time, String from, String to, String text) {
        append("[" + time + "] ", style(Theme.MUTED, false, false));
        append("(private) " + from + " -> " + to + ": " + text + "\n", style(Theme.PURPLE, true, true));
    }

    private void appendSystem(String time, String text) {
        append("[" + time + "] * " + text + "\n", style(Theme.MUTED, false, true));
    }

    private void appendError(String text) {
        append("[" + now() + "] ! " + text + "\n", style(Theme.RED, true, false));
    }

    private void append(String text, SimpleAttributeSet attrs) {
        StyledDocument doc = chatPane.getStyledDocument();
        try {
            doc.insertString(doc.getLength(), text, attrs);
        } catch (BadLocationException ignored) {
            // cannot happen: we always insert at the end
        }
        chatPane.setCaretPosition(doc.getLength());   // auto-scroll
    }

    private static SimpleAttributeSet style(Color color, boolean bold, boolean italic) {
        SimpleAttributeSet a = new SimpleAttributeSet();
        StyleConstants.setForeground(a, color);
        StyleConstants.setBold(a, bold);
        StyleConstants.setItalic(a, italic);
        StyleConstants.setFontSize(a, 14);
        return a;
    }

    private static String now() {
        return LocalTime.now().format(TIME);
    }
}
