package studycircle;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.Collection;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;

/**
 * Study Circle feature #2: group poll with live results.
 * Someone starts a poll (e.g. "Which topic should we review first?") and everybody
 * votes once. The server counts votes and broadcasts POLL_STATE after every vote,
 * so the bars on every client move in real time.
 */
class PollPanel extends JPanel {

    private static final String CARD_CREATE = "create";
    private static final String CARD_VIEW = "view";

    private final Consumer<String> sender;
    private final String myNick;

    private final CardLayout cards = new CardLayout();
    private final JTextField questionField = new JTextField();
    private final JTextField[] optionFields = new JTextField[4];

    private final JLabel pollTitle = new JLabel(" ");
    private final JLabel pollMeta = Theme.mutedLabel(" ");
    private final JPanel optionsBox = new JPanel();
    private final JButton endButton = new JButton("Close poll");
    private final JButton newButton = Theme.primaryButton("Start a new poll");

    private String[] lastState;
    private int votedPollId = -1;
    private Collection<String> online = java.util.Collections.emptyList();

    PollPanel(Consumer<String> sender, String myNick) {
        super();
        this.sender = sender;
        this.myNick = myNick;
        setLayout(cards);
        add(buildCreateCard(), CARD_CREATE);
        add(buildViewCard(), CARD_VIEW);
        cards.show(this, CARD_CREATE);
    }

    private JPanel buildCreateCard() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(Theme.padding(12));

        p.add(left(Theme.mutedLabel("No poll is running. Ask the group to decide something:")));
        p.add(Box.createVerticalStrut(8));
        p.add(left(new JLabel("Question")));
        p.add(stretch(questionField));
        p.add(Box.createVerticalStrut(8));
        p.add(left(new JLabel("Options (at least 2)")));
        for (int i = 0; i < optionFields.length; i++) {
            optionFields[i] = new JTextField();
            p.add(Box.createVerticalStrut(4));
            p.add(stretch(optionFields[i]));
        }
        p.add(Box.createVerticalStrut(10));
        JButton start = Theme.primaryButton("Start poll");
        start.addActionListener(e -> startPoll());
        p.add(left(start));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel buildViewCard() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBorder(Theme.padding(12));

        JPanel top = new JPanel(new BorderLayout());
        pollTitle.setFont(Theme.BOLD.deriveFont(16f));
        top.add(pollTitle, BorderLayout.NORTH);
        top.add(pollMeta, BorderLayout.SOUTH);
        p.add(top, BorderLayout.NORTH);

        optionsBox.setLayout(new BoxLayout(optionsBox, BoxLayout.Y_AXIS));
        p.add(optionsBox, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        endButton.addActionListener(e -> sender.accept(Protocol.build("POLL_END")));
        newButton.addActionListener(e -> cards.show(this, CARD_CREATE));
        bottom.add(endButton);
        bottom.add(newButton);
        p.add(bottom, BorderLayout.SOUTH);
        return p;
    }

    private void startPoll() {
        java.util.List<String> fields = new java.util.ArrayList<>();
        fields.add(questionField.getText().trim());
        for (JTextField f : optionFields) {
            if (!f.getText().trim().isEmpty()) {
                fields.add(f.getText().trim());
            }
        }
        if (fields.get(0).isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Type a question for the poll.",
                    "Poll", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (fields.size() < 3) {
            javax.swing.JOptionPane.showMessageDialog(this, "Add at least two options.",
                    "Poll", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        sender.accept(Protocol.build("POLL_START", fields.toArray(new String[0])));
        questionField.setText("");
        for (JTextField f : optionFields) {
            f.setText("");
        }
    }

    /** Called when the list of online users changes (the owner may have left). */
    void setOnlineUsers(Collection<String> names) {
        this.online = names;
        updateButtons();
    }

    /** POLL_STATE|id|status|question|owner|option|count|option|count... */
    void applyState(String[] p) {
        lastState = p;
        String status = Protocol.arg(p, 2);
        if ("NONE".equals(status)) {
            cards.show(this, CARD_CREATE);
            return;
        }
        int id;
        try {
            id = Integer.parseInt(Protocol.arg(p, 1));
        } catch (NumberFormatException e) {
            return;
        }
        boolean open = "OPEN".equals(status);
        int optionCount = (p.length - 5) / 2;
        int total = 0;
        for (int i = 0; i < optionCount; i++) {
            total += parse(Protocol.arg(p, 6 + i * 2));
        }

        pollTitle.setText(Protocol.arg(p, 3));
        pollMeta.setText("Started by " + Protocol.arg(p, 4) + "  |  " + (open ? "OPEN" : "CLOSED")
                + "  |  " + total + (total == 1 ? " vote" : " votes"));

        boolean canVote = open && votedPollId != id;
        optionsBox.removeAll();
        for (int i = 0; i < optionCount; i++) {
            final int index = i;
            String name = Protocol.arg(p, 5 + i * 2);
            int count = parse(Protocol.arg(p, 6 + i * 2));

            JProgressBar bar = new JProgressBar(0, Math.max(total, 1));
            bar.setValue(count);
            bar.setStringPainted(true);
            int pct = total == 0 ? 0 : Math.round(count * 100f / total);
            bar.setString(count + "  (" + pct + "%)");
            bar.setForeground(open ? Theme.NAVY : Theme.MUTED);

            JButton vote = new JButton("Vote");
            vote.setEnabled(canVote);
            final int pollId = id;
            vote.addActionListener(e -> {
                votedPollId = pollId;
                sender.accept(Protocol.build("POLL_VOTE", String.valueOf(index)));
                applyState(lastState);   // refresh so the vote buttons switch off at once
            });

            JPanel row = new JPanel(new BorderLayout(8, 2));
            row.setBorder(BorderFactory.createEmptyBorder(4, 0, 6, 0));
            row.add(new JLabel(name), BorderLayout.NORTH);
            row.add(bar, BorderLayout.CENTER);
            row.add(vote, BorderLayout.EAST);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            optionsBox.add(row);
        }
        if (open && votedPollId == id) {
            JLabel voted = new JLabel("Your vote is counted.");
            voted.setForeground(Theme.GREEN);
            voted.setAlignmentX(Component.LEFT_ALIGNMENT);
            optionsBox.add(voted);
        }
        newButton.setVisible(!open);
        updateButtons();
        optionsBox.revalidate();
        optionsBox.repaint();
        cards.show(this, CARD_VIEW);
    }

    /** The owner can close the poll; anyone can if the owner has left. */
    private void updateButtons() {
        if (lastState == null || !"OPEN".equals(Protocol.arg(lastState, 2))) {
            endButton.setVisible(false);
            return;
        }
        String owner = Protocol.arg(lastState, 4);
        boolean ownerOnline = false;
        for (String n : online) {
            if (n.equalsIgnoreCase(owner)) {
                ownerOnline = true;
                break;
            }
        }
        endButton.setVisible(owner.equalsIgnoreCase(myNick) || !ownerOnline);
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static JPanel left(Component c) {
        JPanel w = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        w.add(c);
        w.setMaximumSize(new Dimension(Integer.MAX_VALUE, w.getPreferredSize().height + 4));
        w.setAlignmentX(Component.LEFT_ALIGNMENT);
        return w;
    }

    private static JTextField stretch(JTextField f) {
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, f.getPreferredSize().height + 4));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        return f;
    }
}
