package studycircle;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

/** Starting window: choose to run the server or open a client. */
public class Launcher extends JFrame {

    public Launcher() {
        super("Study Circle");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setBackground(Theme.NAVY);
        header.setBorder(Theme.padding(18));
        header.add(Theme.titleLabel("Study Circle"));
        JLabel sub = new JLabel("Review together: ask questions, vote on topics");
        sub.setForeground(Theme.AMBER);
        header.add(sub);

        JButton server = Theme.primaryButton("Start Server (host computer)");
        JButton client = Theme.primaryButton("Open Client (join a circle)");
        server.addActionListener(e -> new ServerFrame().setVisible(true));
        client.addActionListener(e -> new ConnectFrame().setVisible(true));

        JPanel buttons = new JPanel(new GridLayout(2, 1, 0, 12));
        buttons.setBorder(Theme.padding(18));
        buttons.setBackground(Theme.PAPER);
        buttons.add(server);
        buttons.add(client);

        JLabel hint = Theme.mutedLabel("Run the server once, then open a client for each person.");
        hint.setHorizontalAlignment(SwingConstants.CENTER);
        hint.setBorder(Theme.padding(8));

        add(header, BorderLayout.NORTH);
        add(buttons, BorderLayout.CENTER);
        add(hint, BorderLayout.SOUTH);
        pack();
        setSize(Math.max(getWidth(), 380), getHeight());
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        Theme.apply();
        SwingUtilities.invokeLater(() -> new Launcher().setVisible(true));
    }
}
