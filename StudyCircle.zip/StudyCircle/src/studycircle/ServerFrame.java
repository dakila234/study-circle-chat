package studycircle;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/** Window that controls a ChatServer: choose the port, start/stop, watch the log. */
public class ServerFrame extends JFrame implements ChatServer.Listener {

    private final ChatServer server = new ChatServer(this);
    private final JTextField portField = new JTextField(String.valueOf(Protocol.DEFAULT_PORT), 6);
    private final JButton toggleButton = Theme.primaryButton("Start server");
    private final JLabel statusLabel = new JLabel("Stopped");
    private final JLabel usersLabel = new JLabel("Online: 0");
    private final JTextArea logArea = new JTextArea();

    public ServerFrame() {
        super("Study Circle - Server");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.NAVY);
        header.setBorder(Theme.padding(12));
        header.add(Theme.titleLabel("Study Circle Server"), BorderLayout.WEST);
        usersLabel.setForeground(Theme.AMBER);
        usersLabel.setFont(Theme.BOLD);
        header.add(usersLabel, BorderLayout.EAST);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        controls.add(new JLabel("Port:"));
        controls.add(portField);
        controls.add(toggleButton);
        controls.add(statusLabel);

        JLabel ips = Theme.mutedLabel("Clients on other computers connect to: " + localAddresses());
        ips.setBorder(Theme.padding(6));

        JPanel top = new JPanel(new BorderLayout());
        top.add(header, BorderLayout.NORTH);
        top.add(controls, BorderLayout.CENTER);
        top.add(ips, BorderLayout.SOUTH);

        logArea.setEditable(false);
        logArea.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 13));
        logArea.setLineWrap(true);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(logArea), BorderLayout.CENTER);

        toggleButton.addActionListener(e -> toggle());
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                server.stop();
            }
        });

        setSize(560, 420);
        setLocationRelativeTo(null);
    }

    private void toggle() {
        if (server.isRunning()) {
            server.stop();
            toggleButton.setText("Start server");
            portField.setEnabled(true);
            statusLabel.setText("Stopped");
            return;
        }
        int port;
        try {
            port = Integer.parseInt(portField.getText().trim());
            if (port < 1024 || port > 65535) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Port must be a number from 1024 to 65535.",
                    "Invalid port", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            server.start(port);
            toggleButton.setText("Stop server");
            portField.setEnabled(false);
            statusLabel.setText("Running on port " + port);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not start the server:\n" + ex.getMessage()
                    + "\n\nIs another server already using this port?",
                    "Start failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Called from server threads, so hop onto the Swing thread. */
    @Override
    public void onLog(String message) {
        SwingUtilities.invokeLater(() -> {
            logArea.append(message + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    @Override
    public void onUserCountChanged(int count) {
        SwingUtilities.invokeLater(() -> usersLabel.setText("Online: " + count));
    }

    private static String localAddresses() {
        StringBuilder sb = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address) {
                        if (sb.length() > 0) {
                            sb.append(", ");
                        }
                        sb.append(a.getHostAddress());
                    }
                }
            }
        } catch (SocketException ignored) {
            // just show nothing
        }
        return sb.length() == 0 ? "(no network found)" : sb.toString();
    }

    public static void main(String[] args) {
        Theme.apply();
        SwingUtilities.invokeLater(() -> {
            ServerFrame f = new ServerFrame();
            f.setDefaultCloseOperation(EXIT_ON_CLOSE);
            f.setVisible(true);
        });
    }
}
