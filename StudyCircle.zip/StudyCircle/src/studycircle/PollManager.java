package studycircle;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Server-side state of the group poll (Study Circle feature #2).
 * One poll at a time. Votes are counted on the server so every client sees the same numbers.
 */
class PollManager {

    private int pollId = 0;
    private String status = "NONE";          // NONE, OPEN or CLOSED
    private String question = "";
    private String owner = "";
    private final List<String> options = new ArrayList<>();
    private int[] counts = new int[0];
    private final Set<String> voters = new HashSet<>();

    synchronized void reset() {
        pollId = 0;
        status = "NONE";
        question = "";
        owner = "";
        options.clear();
        counts = new int[0];
        voters.clear();
    }

    /** @return error message, or null on success */
    synchronized String start(String user, String q, List<String> opts) {
        if ("OPEN".equals(status)) {
            return "A poll is already running. Wait for it to be closed.";
        }
        q = q == null ? "" : q.trim();
        if (q.isEmpty()) {
            return "Poll question cannot be empty.";
        }
        if (q.length() > Protocol.MAX_POLL_TEXT) {
            q = q.substring(0, Protocol.MAX_POLL_TEXT);
        }
        List<String> clean = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (String o : opts) {
            String t = o == null ? "" : o.trim();
            if (t.isEmpty()) {
                continue;
            }
            if (t.length() > Protocol.MAX_OPTION) {
                t = t.substring(0, Protocol.MAX_OPTION);
            }
            if (seen.add(t.toLowerCase(Locale.ROOT))) {
                clean.add(t);
            }
        }
        if (clean.size() < 2 || clean.size() > 5) {
            return "A poll needs 2 to 5 different options.";
        }
        pollId++;
        status = "OPEN";
        question = q;
        owner = user;
        options.clear();
        options.addAll(clean);
        counts = new int[clean.size()];
        voters.clear();
        return null;
    }

    /** @return error message, or null on success */
    synchronized String vote(String user, int index) {
        if (!"OPEN".equals(status)) {
            return "There is no open poll.";
        }
        if (index < 0 || index >= options.size()) {
            return "That option does not exist.";
        }
        if (!voters.add(user.toLowerCase(Locale.ROOT))) {
            return "You already voted in this poll.";
        }
        counts[index]++;
        return null;
    }

    /** @return error message, or null on success. Anyone may close the poll if its owner left. */
    synchronized String close(String user, boolean ownerOnline) {
        if (!"OPEN".equals(status)) {
            return "There is no open poll.";
        }
        if (ownerOnline && !owner.equalsIgnoreCase(user)) {
            return "Only " + owner + " can close this poll.";
        }
        status = "CLOSED";
        return null;
    }

    synchronized String getOwner() {
        return owner;
    }

    synchronized String getQuestion() {
        return question;
    }

    /** POLL_STATE|id|status|question|owner|option|count|option|count|... */
    synchronized String stateLine() {
        if ("NONE".equals(status)) {
            return Protocol.build("POLL_STATE", "0", "NONE");
        }
        List<String> fields = new ArrayList<>();
        fields.add(String.valueOf(pollId));
        fields.add(status);
        fields.add(question);
        fields.add(owner);
        for (int i = 0; i < options.size(); i++) {
            fields.add(options.get(i));
            fields.add(String.valueOf(counts[i]));
        }
        return Protocol.build("POLL_STATE", fields.toArray(new String[0]));
    }
}
