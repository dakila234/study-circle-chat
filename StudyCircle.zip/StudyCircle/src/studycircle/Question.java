package studycircle;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** One entry of the shared Question Queue. Only accessed through QuestionBoard. */
class Question {
    final int id;
    final String author;
    final String text;
    boolean answered;
    String answeredBy = "";
    final Set<String> upvoters = new HashSet<>();

    Question(int id, String author, String text) {
        this.id = id;
        this.author = author;
        this.text = text;
    }

    int votes() {
        return upvoters.size();
    }

    boolean hasVoted(String nick) {
        return upvoters.contains(nick.toLowerCase(Locale.ROOT));
    }

    /** Protocol line that tells clients to add or refresh this question. */
    String toLine() {
        return Protocol.build("Q_SET",
                String.valueOf(id), author, text,
                answered ? "DONE" : "OPEN",
                String.valueOf(votes()), answeredBy);
    }
}
