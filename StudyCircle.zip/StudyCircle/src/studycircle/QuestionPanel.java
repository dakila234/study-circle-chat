package studycircle;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.util.function.Consumer;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * Study Circle feature #1: the shared Question Queue.
 * Everyone sees the same list. Members can ask a question, "+1" a question they
 * also need answered, and mark a question as answered. The server owns the data;
 * this panel only displays what the server sends (Q_RESET / Q_SET).
 */
class QuestionPanel extends JPanel {

    private static final int COL_ID = 0;
    private static final int COL_STATUS = 4;

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[] {"#", "Question", "Asked by", "+1", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return (columnIndex == COL_ID || columnIndex == 3) ? Integer.class : String.class;
        }
    };
    private final JTable table = new JTable(model);
    private final JTextField questionField = new JTextField();
    private final Consumer<String> sender;

    QuestionPanel(Consumer<String> sender) {
        super(new BorderLayout(6, 6));
        this.sender = sender;
        setBorder(Theme.padding(8));

        JLabel hint = Theme.mutedLabel("Ask what you are stuck on. Others can +1 it; mark it answered when solved.");
        add(hint, BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(24);
        table.getColumnModel().getColumn(0).setMaxWidth(36);
        table.getColumnModel().getColumn(1).setPreferredWidth(240);
        table.getColumnModel().getColumn(2).setPreferredWidth(80);
        table.getColumnModel().getColumn(3).setMaxWidth(40);
        table.getColumnModel().getColumn(4).setPreferredWidth(110);
        table.setDefaultRenderer(Object.class, new RowRenderer());
        table.setDefaultRenderer(Integer.class, new RowRenderer());
        table.setDefaultRenderer(String.class, new RowRenderer());
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton askButton = Theme.primaryButton("Ask");
        JButton plusOne = new JButton("+1 Me too");
        JButton done = new JButton("Mark answered");
        askButton.addActionListener(e -> ask());
        questionField.addActionListener(e -> ask());
        plusOne.addActionListener(e -> sendForSelected("Q_UP"));
        done.addActionListener(e -> sendForSelected("Q_DONE"));

        JPanel askRow = new JPanel(new BorderLayout(6, 0));
        askRow.add(questionField, BorderLayout.CENTER);
        askRow.add(askButton, BorderLayout.EAST);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        actions.add(plusOne);
        actions.add(done);

        JPanel bottom = new JPanel(new BorderLayout(0, 6));
        bottom.add(askRow, BorderLayout.NORTH);
        bottom.add(actions, BorderLayout.SOUTH);
        add(bottom, BorderLayout.SOUTH);
    }

    void ask() {
        String text = questionField.getText().trim();
        if (text.isEmpty()) {
            return;
        }
        sender.accept(Protocol.build("Q_ADD", text));
        questionField.setText("");
    }

    private void sendForSelected(String command) {
        int row = table.getSelectedRow();
        if (row < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Select a question in the list first.",
                    "No question selected", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Object id = model.getValueAt(table.convertRowIndexToModel(row), COL_ID);
        sender.accept(Protocol.build(command, String.valueOf(id)));
    }

    /** Q_RESET: the server is about to resend the whole queue. */
    void reset() {
        model.setRowCount(0);
    }

    /** Q_SET|id|author|text|status|votes|answeredBy: add or update one row. */
    void applyQuestion(String[] p) {
        int id;
        int votes;
        try {
            id = Integer.parseInt(Protocol.arg(p, 1));
            votes = Integer.parseInt(Protocol.arg(p, 5));
        } catch (NumberFormatException e) {
            return;
        }
        String author = Protocol.arg(p, 2);
        String text = Protocol.arg(p, 3);
        boolean done = "DONE".equals(Protocol.arg(p, 4));
        String answeredBy = Protocol.arg(p, 6);
        String status = done ? "Answered by " + answeredBy : "Open";

        for (int i = 0; i < model.getRowCount(); i++) {
            if (((Integer) model.getValueAt(i, COL_ID)) == id) {
                model.setValueAt(votes, i, 3);
                model.setValueAt(status, i, COL_STATUS);
                return;
            }
        }
        model.addRow(new Object[] {id, text, author, votes, status});
    }

    /** Green background for answered questions. */
    private static final class RowRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                boolean focus, int row, int column) {
            Component c = super.getTableCellRendererComponent(t, value, selected, focus, row, column);
            if (!selected) {
                Object status = t.getModel().getValueAt(t.convertRowIndexToModel(row), COL_STATUS);
                boolean answered = status != null && status.toString().startsWith("Answered");
                c.setBackground(answered ? Theme.DONE_ROW : java.awt.Color.WHITE);
                c.setForeground(answered ? Theme.MUTED : Theme.INK);
            }
            return c;
        }
    }
}
