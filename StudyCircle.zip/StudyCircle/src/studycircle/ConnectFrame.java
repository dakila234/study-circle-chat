package studycircle;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

/** Login window: server address, port and a unique nickname. */
public class ConnectFrame extends JFrame {

    private final JTextField hostField = new JTextField("localhost", 16);
    private final JTextField portField = new JTextField(String.valueOf(Protocol.DEFAULT_PORT), 16);
    private final JTextField nickField = new JTextField(16);
    private final JButton connectButton = Theme.primaryButton("Join the circle");
    private final JLabel statusLabel = new JLabel(" ");

    public ConnectFrame() {
        super("Study Circle - Join");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.NAVY);
        header.setBorder(Theme.padding(14));
        header.add(Theme.titleLabel("Join a Study Circle"), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(Theme.padding(16));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.WEST;
        addRow(form, c, 0, "Server address:", hostField);
        addRow(form, c, 1, "Port:", portField);
        addRow(form, c, 2, "Nickname:", nickField);

        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 2;
        c.fill = GridBagConstraints.HORIZONTAL;
        form.add(connectButton, c);
        c.gridy = 4;
        statusLabel.setForeground(Theme.RED);
        form.add(statusLabel, c);

        add(header, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);

        connectButton.addActionListener(e -> connect());
        nickField.addActionListener(e -> connect());
        getRootPane().setDefaultButton(connectButton);

        pack();
        setLocationRelativeTo(null);
    }

    private static void addRow(JPanel form, GridBagConstraints c, int row, String label, JTextField field) {
        c.gridy = row;
        c.gridwidth = 1;
        c.fill = GridBagConstraints.NONE;
        c.gridx = 0;
        form.add(new JLabel(label), c);
        c.gridx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        form.add(field, c);
    }

    private void connect() {
        final String host = hostField.getText().trim();
        final String nick = nickField.getText().trim();
        final int port;

        if (host.isEmpty()) {
            showError("Enter the server address.");
            return;
        }
        try {
            port = Integer.parseInt(portField.getText().trim());
            if (port < 1 || port > 65535) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            showError("Port must be a number from 1 to 65535.");
            return;
        }
        String nickProblem = Protocol.validateNickname(nick);
        if (nickProblem != null) {
            showError(nickProblem);
            return;
        }

        setBusy(true);
        statusLabel.setForeground(Theme.MUTED);
        statusLabel.setText("Connecting...");

        // Networking runs off the Swing thread so the window never freezes.
        new SwingWorker<ClientConnection, Void>() {
            @Override
            protected ClientConnection doInBackground() throws Exception {
                ClientConnection conn = new ClientConnection();
                conn.connect(host, port, nick);
                return conn;
            }

            @Override
            protected void done() {
                try {
                    ClientConnection conn = get();
                    new MainFrame(conn, nick, host, port).setVisible(true);
                    dispose();
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    showError(friendly(cause));
                    setBusy(false);
                }
            }
        }.execute();
    }

    private static String friendly(Throwable t) {
        String m = t.getMessage();
        if (t instanceof java.net.ConnectException) {
            return "Could not reach the server. Is it running, and are the address and port right?";
        }
        if (t instanceof java.net.UnknownHostException) {
            return "Unknown server address: " + m;
        }
        if (t instanceof java.net.SocketTimeoutException) {
            return "The server did not answer in time.";
        }
        return m == null ? "Connection failed." : m;
    }

    private void showError(String message) {
        statusLabel.setForeground(Theme.RED);
        statusLabel.setText(message);
        pack();
    }

    private void setBusy(boolean busy) {
        connectButton.setEnabled(!busy);
        hostField.setEnabled(!busy);
        portField.setEnabled(!busy);
        nickField.setEnabled(!busy);
    }

    public static void main(String[] args) {
        Theme.apply();
        SwingUtilities.invokeLater(() -> {
            ConnectFrame f = new ConnectFrame();
            f.setDefaultCloseOperation(EXIT_ON_CLOSE);
            f.setVisible(true);
        });
    }
}
