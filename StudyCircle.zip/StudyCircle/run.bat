@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -d out src\studycircle\*.java && java -cp out studycircle.Launcher
pause
