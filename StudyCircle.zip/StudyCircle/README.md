# Study Circle

A group chat for classmates who are reviewing a subject together. Plain chat makes questions
disappear and decisions get lost, so Study Circle adds two shared tools next to the chat:

1. **Question Queue** - members post what they are stuck on, others "+1" it, and anyone can mark it answered.
2. **Group Poll with live results** - decide what to review first; bars update on every screen as votes come in.

Built with Java Swing (JFrame) in Apache NetBeans. Plain TCP sockets, no external libraries.

## Concept Proposal

| | |
|---|---|
| **Audience** | Classmates reviewing a subject together |
| **Problem** | In ordinary chat, questions get buried and nobody can tell which are still unanswered or what the group decided |
| **Feature 1** | Shared Question Queue (ask, +1, mark answered; same list for everyone) |
| **Feature 2** | Group Poll with live results (one vote per person, owner closes the poll) |
| **Sample screens** | _Add screenshots here: join screen, chat + Online tab, Questions tab, Poll tab_ |
| **Instructor approval** | _Name / date:_ |

## How to run (NetBeans)

1. Unzip `StudyCircle.zip`.
2. NetBeans: **File > Open Project...** and pick the `StudyCircle` folder.
3. Right-click the project > **Run** (main class is `studycircle.Launcher`).
4. In the launcher: **Start Server** on the host computer, then **Open Client** for each user.
5. On a second computer, open a client and enter the host's IP address (shown in the Server window) and port `5050`.

If NetBeans cannot open it as a project: create a new *Java with Ant > Java Application*, then copy the
`src/studycircle` files into it. Or run `run.bat` (Windows) / `run.sh` (Linux/Mac) with a JDK installed.

Requires JDK 11 or newer. Both computers must be on the same network and the server's firewall must allow the port.

## Commands

| Command | What it does |
|---|---|
| `/list` | show who is online |
| `/msg <nick> <text>` | private message |
| `/quit` | leave the chat |
| `/ask <question>` | add to the Question Queue |
| `/up <#>` / `/done <#>` | +1 a question / mark it answered |
| `/poll Question \| opt1 \| opt2 ...` | start a poll (2-5 options) |
| `/vote <n>` / `/endpoll` | vote for option n / close your poll |
| `/help` | list commands |

## Code overview

| File | Responsibility |
|---|---|
| `Protocol` | message format (`COMMAND\|field\|field`, fields URL-encoded), nickname validation |
| `ChatServer` | accept loop, online users, broadcast |
| `ClientHandler` | one thread per client; reads and handles that client's messages |
| `QuestionBoard`, `Question` | server-side question queue (synchronized) |
| `PollManager` | server-side poll state and vote counting (synchronized) |
| `ClientConnection` | client socket, HELLO handshake, reader thread |
| `ConnectFrame` | join screen (host, port, nickname); connects in a `SwingWorker` |
| `MainFrame` | chat window; moves incoming messages onto the Swing thread |
| `QuestionPanel`, `PollPanel` | GUI for the two features |
| `ServerFrame`, `Launcher`, `Theme` | server window, start window, shared styling |

Message path: user types -> `MainFrame` -> `ClientConnection.send` -> socket -> `ClientHandler.handle`
-> `ChatServer.broadcast` -> every `ClientHandler.send` -> each client's reader thread
-> `SwingUtilities.invokeLater` -> GUI update.

## Test evidence

_Fill in with screenshots and results._

| Test | Expected | Result |
|---|---|---|
| Server + 3 clients across 2 computers | all connect | |
| Duplicate / invalid nickname | rejected with message | |
| Group message | each client receives it once, with sender and time | |
| Join / leave | notice + online list updates | |
| One client disconnects | others keep chatting | |
| `/list`, `/msg`, `/quit` | work | |
| Question: ask, +1, mark answered | same on all clients | |
| Poll: vote, live bars, close | same on all clients; one vote each | |

## Contribution log

| Partner | Work done | Evidence (commits, screenshots) |
|---|---|---|
| Partner 1 | | |
| Partner 2 | | |

## Credits and AI assistance

- Java SE / Swing (JDK standard library only).
- Code was generated with assistance from Claude (Anthropic) and then reviewed by the team.
  _Edit this line to describe what you changed or wrote yourselves._
