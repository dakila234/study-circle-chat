#!/bin/sh
# Compiles and starts the Study Circle launcher (needs a JDK).
cd "$(dirname "$0")"
mkdir -p out
javac -d out src/studycircle/*.java && java -cp out studycircle.Launcher
